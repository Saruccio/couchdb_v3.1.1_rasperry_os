============
couchdb-bear
============

A set of statistics functions for erlang. Currently bear is focused on use 
inside the Folsom Erlang metrics library but all of these functions are generic 
and useful in other situations.

This is a fork of https://github.com/boundary/bear project.

License
=======

Apache 2.0
